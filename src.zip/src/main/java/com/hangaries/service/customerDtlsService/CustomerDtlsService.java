package com.hangaries.service.customerDtlsService;

import com.hangaries.model.CustomerDtls;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CustomerDtlsService {

    public void saveCustomerDtls(CustomerDtls customerDtls) throws Exception;

    public void updateCustomerDtls(CustomerDtls customerDtls) throws Exception;

    public List<CustomerDtls> getCustomerAddressDtlsByMobNum(String mobnum) throws Exception;
}
