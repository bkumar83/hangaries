package com.hangaries.service.menuDishpointService.Impl;


import com.hangaries.service.menuDishpointService.MenuDishpointService;
import org.springframework.stereotype.Service;

@Service
public class MenuDishpointServiceImpl implements MenuDishpointService {

}
