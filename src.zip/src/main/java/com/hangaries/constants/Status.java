package com.hangaries.constants;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE,

}