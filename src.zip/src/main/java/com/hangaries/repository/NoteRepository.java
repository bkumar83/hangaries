package com.hangaries.repository;

/**
 * Created by rajeevkumarsingh on 27/06/17.
 */

//@Repository
public interface NoteRepository  {

}
